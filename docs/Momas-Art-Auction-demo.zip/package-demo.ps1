# Build a distributable zip (source only — no node_modules).
# Run from project root:  powershell -ExecutionPolicy Bypass -File .\package-demo.ps1
# Output: docs\Momas-Art-Auction-demo.zip  (+ copies testing guide into docs if rebuilt)

param(
  [string] $OutPath = ""
)

$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
if (-not $OutPath) {
  $OutPath = Join-Path $root "docs\Momas-Art-Auction-demo.zip"
}

$staging = Join-Path $env:TEMP ("momas-art-auction-" + [guid]::NewGuid().ToString("n"))
New-Item -ItemType Directory -Path $staging -Force | Out-Null

Write-Host "Staging copy (excludes node_modules, .git, .cursor, *.zip)..."
robocopy $root $staging /E /XD node_modules .git .cursor /XF *.zip /NFL /NDL /NJH /NJS | Out-Null
if ($LASTEXITCODE -ge 8) { throw "robocopy failed with code $LASTEXITCODE" }

Write-Host "Stripping local DB + uploads from staging..."
$dbDir = Join-Path $staging "server\data"
if (Test-Path $dbDir) {
  Get-ChildItem -Path $dbDir -Include "auction.db*","*.db-wal","*.db-shm" -Recurse -ErrorAction SilentlyContinue |
    Remove-Item -Force -ErrorAction SilentlyContinue
}
$uploads = Join-Path $staging "server\uploads"
if (Test-Path $uploads) {
  Get-ChildItem -Path $uploads -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne ".gitkeep" } |
    Remove-Item -Force -ErrorAction SilentlyContinue
}

Write-Host "Compressing to $OutPath ..."
$docsParent = Split-Path $OutPath -Parent
if (-not (Test-Path $docsParent)) { New-Item -ItemType Directory -Path $docsParent -Force | Out-Null }
if (Test-Path $OutPath) { Remove-Item $OutPath -Force }
Compress-Archive -Path (Join-Path $staging "*") -DestinationPath $OutPath -CompressionLevel Optimal

Remove-Item -Path $staging -Recurse -Force

Write-Host "Done."
Write-Host "  Zip: $OutPath"
Write-Host "  Testing guide (Word): $(Join-Path $root 'docs\Momas-Local-Demo-Guide.docx')"
Write-Host "Regenerate the Word guide with:  pip install python-docx  &&  python docs\build_local_demo_docx.py"
